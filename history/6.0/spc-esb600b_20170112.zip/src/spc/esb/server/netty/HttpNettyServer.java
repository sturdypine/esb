package spc.esb.server.netty;

import java.util.Map;

import javax.annotation.Resource;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.HttpContentCompressor;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;
import io.netty.handler.codec.http.QueryStringDecoder;
import io.netty.handler.timeout.IdleStateHandler;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import spc.esb.common.service.WsdlService;
import spc.esb.core.service.ESBService;
import spc.esb.data.AtomNode;
import spc.esb.data.IMessage;
import spc.esb.data.converter.MessageConverter;
import spc.esb.data.converter.SOAPConverter;
import spc.webos.constant.Common;
import spc.webos.server.netty.AbstractNettyServer;
import spc.webos.server.netty.FullHttpServerInboundHandler;
import spc.webos.util.JsonUtil;
import spc.webos.util.StringX;

public class HttpNettyServer extends AbstractNettyServer
{
	public HttpNettyServer()
	{
	}

	public HttpNettyServer(int port)
	{
		this.port = port;
	}

	public void bootstrap() throws Exception
	{
		final HttpNettyServer server = this;
		bootstrap.group(bossGroup, workerGroup).channel(NioServerSocketChannel.class)
				.childHandler(new ChannelInitializer<SocketChannel>()
				{
					public void initChannel(SocketChannel ch) throws Exception
					{
						ch.pipeline().addLast("idle", new IdleStateHandler(0, 0, idleTimeout));
						ch.pipeline().addLast("readtimeout", new ReadTimeoutHandler(readTimeout));
						ch.pipeline().addLast("writetimeout",
								new WriteTimeoutHandler(writeTimeout));
						ch.pipeline().addLast("decoder", new HttpRequestDecoder()); // inbound:1
						ch.pipeline().addLast("encoder", new HttpResponseEncoder()); // outbound:2
						ch.pipeline().addLast("aggregator",
								new HttpObjectAggregator(maxContentLength)); // inbound:2
						ch.pipeline().addLast("deflater", new HttpContentCompressor()); // outbound:1
						ch.pipeline().addLast("handler", new FullHttpServerInboundHandler(server,
								Common.FILE_XML_CONTENTTYPE)
						{
							protected void doPost(ChannelHandlerContext ctx) throws Exception
							{
								String uri = fullHttpRequest.uri();
								String[] uris = StringX.split(uri, "/");
								String msgType = uris[1]; // ��һ�������Ǳ������ͣ�ͨ�����������ҽ�������index=0�ǿ��ַ���
								String msgCd = uris[uris.length - 1]; // ���һ�������Ǳ��ı��
								String sndAppCd = fullHttpRequest.headers().get("sndAppCd");
								if (StringX.nullity(sndAppCd)) sndAppCd = Common.APP_CD_ESB;
								byte[] request = new byte[fullHttpRequest.content().capacity()];
								fullHttpRequest.content().readBytes(request);
								// byte[] request =
								// fullHttpRequest.content().copy().array();
								log.info("request len:{}, msgType:{}, sndAppCd:{}, msgCd:{}",
										request.length, msgType, sndAppCd, msgCd);
								if (log.isDebugEnabled())
									log.debug("request base64:{}", StringX.base64(request));
								MessageConverter converter = ((HttpNettyServer) server).converters
										.get(msgType);
								IMessage msg = converter.deserialize(request);
								if (StringX.nullity(msg.getMsgCd())) msg.setMsgCd(msgCd);
								if (StringX.nullity(msg.getSndApp()) && !StringX.nullity(sndAppCd))
									msg.setSndAppCd(sndAppCd);

								msg = ((HttpNettyServer) server).esbService.sync(msg);
								byte[] buf = converter.serialize(msg);
								if (!StringX.nullity(converter.getContentType()))
									this.contentType = converter.getContentType();
								writeResponse(ctx.channel(), buf, 0);
							}

							protected void doGet(ChannelHandlerContext ctx) throws Exception
							{
								String uri = fullHttpRequest.uri();
								int idx = uri.indexOf('?');
								if (idx > 0) uri = uri.substring(0, idx);
								idx = uri.lastIndexOf('/');
								String msgCd = uri.substring(idx + 1);
								QueryStringDecoder decoder = new QueryStringDecoder(
										fullHttpRequest.uri());
								if (decoder.parameters().containsKey("wsdl"))
									writeResponse(ctx.channel(), wsdlService.wsdl(msgCd).getBytes(),
											0);
								else if (decoder.parameters().containsKey("schema"))
									writeResponse(ctx.channel(),
											wsdlService.schema(msgCd).getBytes(), 0);
								else if (decoder.parameters().containsKey("json"))
								{ // json sample
									contentType = Common.FILE_JSON_CONTENTTYPE;
									IMessage msg = SOAPConverter.getInstance()
											.deserialize(wsdlService.sample(msgCd, 0).getBytes());
									writeResponse(ctx.channel(),
											JsonUtil.obj2json(msg.getTransaction(), AtomNode.class)
													.getBytes(),
											0);
								}
								else if (decoder.parameters().containsKey("rest"))
								{ // json rest sample
									contentType = Common.FILE_JSON_CONTENTTYPE;
									IMessage msg = SOAPConverter.getInstance()
											.deserialize(wsdlService.sample(msgCd, 0).getBytes());
									writeResponse(ctx.channel(), JsonUtil
											.obj2json(msg.getBody(), AtomNode.class).getBytes(), 0);
								}
								else // xml sample
									writeResponse(ctx.channel(),
											wsdlService.sample(msgCd, 0).getBytes(), 0);
							}
						}); // inbound:3
					}
				}).option(ChannelOption.SO_BACKLOG, 128)
				.childOption(ChannelOption.SO_KEEPALIVE, true);
	}

	@Resource
	protected ESBService esbService;
	@Resource
	protected WsdlService wsdlService;
	protected Map<String, MessageConverter> converters;

	public void setEsbService(ESBService esbService)
	{
		this.esbService = esbService;
	}

	public void setWsdlService(WsdlService wsdlService)
	{
		this.wsdlService = wsdlService;
	}

	public void setConverters(Map<String, MessageConverter> converters)
	{
		this.converters = converters;
	}
}
