package spc.esb.common.listener;

import javax.annotation.Resource;
import javax.jms.Message;

import org.springframework.jdbc.CannotGetJdbcConnectionException;

import spc.esb.common.service.JournalService;
import spc.esb.constant.ESBCommon;
import spc.esb.constant.ESBConfig;
import spc.esb.data.IMessage;
import spc.esb.data.converter.SOAPConverter;
import spc.webos.config.AppConfig;
import spc.webos.mq.jms.AbstractBytesMessageListener;

public class ESBLogMessageListener extends AbstractBytesMessageListener
{
	protected void onMessage(Message msg, String queue, String corId, byte[] buf)
	{
		try
		{
			if (queue.indexOf(ESBCommon.DEFAULT_ESBLOG) >= 0)
			{ // is esb.log
				String logPoint = msg.getStringProperty(ESBCommon.JMS_LOGPOINT);
				log.info("LogPoint:{}", logPoint);
				IMessage soap = SOAPConverter.getInstance().deserialize(buf);
				try
				{
					journalService.doJournal(soap, logPoint);
				}
				catch (CannotGetJdbcConnectionException e)
				{
					int sleepSeconds = AppConfig.getInstance()
							.getProperty(ESBConfig.JOURNAL_exSleepSeconds, 30);
					log.warn("db cnn fail:{}, sleep:{}, ex:{}", queue, sleepSeconds, e.toString());
					journalService.sendLog(soap, logPoint);
					Thread.sleep(sleepSeconds * 1000);
				}
			}
			else
			{ // is esb.alarm
				IMessage soap = SOAPConverter.getInstance().deserialize(buf);
				try
				{
					journalService.doAlarm(soap, buf, null, null);
				}
				catch (CannotGetJdbcConnectionException e)
				{
					int sleepSeconds = AppConfig.getInstance()
							.getProperty(ESBConfig.JOURNAL_exSleepSeconds, 30);
					log.warn("db cnn fail:{}, sleep:{}, ex:{}", queue, sleepSeconds, e.toString());
					journalService.sendAlarm(soap);
					Thread.sleep(sleepSeconds * 1000);
				}
			}
		}
		catch (Exception e)
		{
			log.warn("onMessage:", e);
		}
	}

	@Resource
	protected JournalService journalService;

	public void setJournalService(JournalService journalService)
	{
		this.journalService = journalService;
	}
}