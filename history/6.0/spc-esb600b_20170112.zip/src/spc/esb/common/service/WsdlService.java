package spc.esb.common.service;

public interface WsdlService
{
	String sample(String msgCd, int type) throws Exception;

	String wsdl(String msgCd) throws Exception;

	String schema(String msgCd) throws Exception;

	String getVOClass(String msgCd, String pkg) throws Exception;

	void genVOClass(String appCd, String category, String basePkg, String dir) throws Exception;

}
