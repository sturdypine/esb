package spc.esb.flowctrl;

import spc.esb.data.IMessage;
import spc.esb.model.MessagePO;

public interface IFCKey
{
	String key(IMessage msg, MessagePO msgVO, int priority) throws Exception;
}
