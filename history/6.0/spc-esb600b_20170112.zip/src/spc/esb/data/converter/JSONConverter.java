package spc.esb.data.converter;

import java.util.Map;

import spc.esb.data.AtomNode;
import spc.esb.data.CompositeNode;
import spc.esb.data.IMessage;
import spc.esb.data.Message;
import spc.webos.constant.Common;
import spc.webos.util.JsonUtil;

public class JSONConverter extends SOAPConverter
{
	public IMessage deserializeJSON(byte[] buf, IMessage msg) throws Exception
	{
		String json = new String(buf, charset);
		try
		{
			CompositeNode cnode = new CompositeNode((Map) JsonUtil.json2obj(json));
			if (!bodyOnly) return new Message(cnode);
			Message m = new Message();
			m.setBody(cnode);
			return m;
		}
		catch (Exception e)
		{
			log.warn("json:" + json + ",e:" + e);
			throw e;
		}
	}

	public byte[] serialize(IMessage msg) throws Exception
	{
		return JsonUtil.obj2json(bodyOnly ? msg.getBody() : msg.getTransaction(), AtomNode.class)
				.getBytes(charset);
	}

	public String getContentType()
	{
		return Common.FILE_JSON_CONTENTTYPE;
	}

	// ������json����ʱֻ��body�壬û�������ŷ�ṹ������֧��restful�ӿ�
	protected boolean bodyOnly;

	public void setBodyOnly(boolean bodyOnly)
	{
		this.bodyOnly = bodyOnly;
	}
}
