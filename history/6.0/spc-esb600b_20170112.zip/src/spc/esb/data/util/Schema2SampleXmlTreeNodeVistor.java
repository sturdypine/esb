package spc.esb.data.util;

import spc.esb.data.INode;
import spc.esb.model.MsgSchemaPO;
import spc.webos.util.StringX;
import spc.webos.util.tree.TreeNode;

/**
 * ���ݱ��ĵ�schema�ṹ������������
 * 
 * @author spc
 * 
 */
public class Schema2SampleXmlTreeNodeVistor extends AbstractSchema2SampleTreeNodeVistor
{
	public Schema2SampleXmlTreeNodeVistor()
	{
	}

	public Schema2SampleXmlTreeNodeVistor(int level)
	{
		this.level = level;
	}

	public boolean start(TreeNode treeNode, TreeNode parent, int index)
	{
		MsgSchemaPO schema = (MsgSchemaPO) treeNode.getTreeNodeValue();
		buf.append(pretty());
		buf.append('<');
		buf.append(schema.getEsbName());
		buf.append('>');
		if (schema.getFtyp().charAt(0) == INode.TYPE_MAP
				|| schema.getFtyp().charAt(0) == INode.TYPE_ARRAY)
			level++;
		else
		{
			buf.append(getAtomValue(schema));
			buf.append('<');
			buf.append('/');
			buf.append(schema.getEsbName());
			buf.append('>');
		}
		return true;
	}

	protected String getAtomValue(MsgSchemaPO schema)
	{
		return StringX.null2emptystr(schema.getDefValue());
	}

	public boolean end(TreeNode treeNode, TreeNode parent, int index)
	{
		MsgSchemaPO schema = (MsgSchemaPO) treeNode.getTreeNodeValue();
		if (schema.getFtyp().charAt(0) == INode.TYPE_MAP
				|| schema.getFtyp().charAt(0) == INode.TYPE_ARRAY)
		{
			level--;
			buf.append(pretty());
			buf.append('<');
			buf.append('/');
			buf.append(schema.getEsbName());
			buf.append('>');
		}
		return true;
	}
}
