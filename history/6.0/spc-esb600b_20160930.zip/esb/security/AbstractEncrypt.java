package spc.esb.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class AbstractEncrypt implements IEncrypt
{
	public void init() throws Exception
	{
		if (IEncrypt.ENCRYPTS.containsKey(name)) log.warn("IEncrypt(" + name + ") repeated!!!");
		IEncrypt.ENCRYPTS.put(name, this);
	}

	protected Logger log = LoggerFactory.getLogger(getClass());
	protected String name;

	public void setName(String name)
	{
		this.name = name;
	}
}
