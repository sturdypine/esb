package spc.esb.constant;

/**
 * ESB fvmapping id
 * 
 * @author spc
 * 
 */
public class ESBFVMappingId
{
	public final static String RET_CODE = "retcd"; // ������
}
