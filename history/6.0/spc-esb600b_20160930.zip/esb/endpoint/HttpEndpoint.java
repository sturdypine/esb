package spc.esb.endpoint;

import java.io.IOException;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import spc.webos.constant.AppRetCode;
import spc.webos.exception.AppException;
import spc.webos.util.StringX;

public class HttpEndpoint implements Endpoint
{
	public HttpEndpoint()
	{
	}

	public HttpEndpoint(String url)
	{
		this.url = url;
	}

	public void execute(Executable exe) throws Exception
	{
		long start = System.currentTimeMillis();
		log.info("HTTP corId:{}, timeout:{}, url:{}, len:{}", exe.getCorrelationID(),
				exe.getTimeout(), url, (exe.getRequest() == null ? ")" : exe.getRequest().length));
		int statusCode = -1;

		HttpPost post = new HttpPost(url);
		post.setConfig(requestConfig);
		// added by chenjs 2013-03--25�� ��webservice�п�����Ҫ��дsoapaction
		if (exe.reqHttpHeaders != null && exe.reqHttpHeaders.size() > 0)
			exe.reqHttpHeaders.keySet().iterator()
					.forEachRemaining((key) -> post.setHeader(key, exe.reqHttpHeaders.get(key)));
		post.setEntity(new ByteArrayEntity(exe.request));

		try (CloseableHttpClient client = HttpClients.createDefault();
				CloseableHttpResponse response = client.execute(post))
		{
			exe.cnnSnd = true; // httpЭ��������ζ���ɹ�
			statusCode = response.getStatusLine().getStatusCode();
			if (statusCode != HttpStatus.OK.value())
			{
				log.info("HTTP err code:{}", statusCode);
				throw new AppException(AppRetCode.PROTOCOL_HTTP,
						new Object[] { new Integer(statusCode) });
			}
			// ������Ӧ��Ϣ
			byte[] repbuf = EntityUtils.toByteArray(response.getEntity());
			log.info("HTTP response len:{}, cost:{}", repbuf.length,
					(System.currentTimeMillis() - start));
			if (log.isDebugEnabled()) log.debug("rep buf:" + new String(repbuf));
			exe.setResponse(repbuf);
		}
		catch (IOException ioe)
		{
			log.error("HTTP err:" + url + ", code:" + statusCode + ", reqbytes base64:"
					+ (exe.request == null ? "" : new String(StringX.encodeBase64(exe.request))),
					ioe);
			throw new AppException(AppRetCode.PROTOCOL_HTTP,
					new Object[] { url, new Integer(statusCode) });
		}
	}

	public void init() throws Exception
	{
	}

	public void setUrl(String url)
	{
		this.url = url;
	}

	public void close()
	{
	}

	public void setLocation(String location) throws Exception
	{
		this.url = location;
	}

	RequestConfig requestConfig = RequestConfig.custom().setSocketTimeout(1000)
			.setConnectTimeout(500).setConnectionRequestTimeout(60000).build();
	protected String url; // ��̨url��ַ
	protected Logger log = LoggerFactory.getLogger(getClass());
}
