package spc.esb.converter;

import java.util.HashMap;
import java.util.Map;

import spc.esb.data.converter.CoreMessageConverter;
import spc.esb.data.converter.MessageConverter;
import spc.esb.data.converter.SOAPConverter;
import spc.webos.util.StringX;

/**
 * ���ں���, ��mb���ĵ��õ�������ת��������
 * 
 * @author spc
 * 
 */
public abstract class AbstractCoreMsgConverter extends BaseMsgConverter
		implements CoreMessageConverter
{
	protected MessageConverter converter = SOAPConverter.getInstance();
	public static Map<String, CoreMessageConverter> CORE_MC = new HashMap<>();

	public MessageConverter getConverter()
	{
		return converter;
	}

	public void setConverter(MessageConverter converter)
	{
		this.converter = converter;
	}

	public void init() throws Exception
	{
		if (StringX.nullity(name)) return;
		if (CORE_MC.containsKey(name)) log.warn("CORE_MC has contained name: " + name);
		else CORE_MC.put(name, this);
	}
}
