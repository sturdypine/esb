package spc.esb.server.netty;

import java.util.Map.Entry;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.http.DefaultFullHttpResponse;
import io.netty.handler.codec.http.FullHttpRequest;
import io.netty.handler.codec.http.FullHttpResponse;
import io.netty.handler.codec.http.HttpContentCompressor;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpMethod;
import io.netty.handler.codec.http.HttpObject;
import io.netty.handler.codec.http.HttpObjectAggregator;
import io.netty.handler.codec.http.HttpRequestDecoder;
import io.netty.handler.codec.http.HttpResponseEncoder;
import io.netty.handler.codec.http.HttpResponseStatus;
import io.netty.handler.codec.http.HttpVersion;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import spc.esb.core.service.ESBService;
import spc.esb.data.IMessage;
import spc.esb.data.converter.MessageConverter;
import spc.esb.data.converter.SOAPConverter;

public class NettyHttpServer
{
	protected final Logger log = LoggerFactory.getLogger(getClass());
	protected int port;
	protected int readTimeout = 10;
	protected int writeTimeout = 5;
	protected int maxContentLength = 1048576;
	protected EventLoopGroup bossGroup;
	protected EventLoopGroup workerGroup;
	protected ServerBootstrap bootstrap = new ServerBootstrap();
	protected ChannelFuture channel;
	@Resource
	protected ESBService esbService;
	protected MessageConverter converter = new SOAPConverter();

	public NettyHttpServer()
	{
	}

	public NettyHttpServer(int port)
	{
		this.port = port;
	}

	@PostConstruct
	public void start() throws Exception
	{
		log.info("start http sever port:{}", port);
		if (port == 0) return;
		bossGroup = new NioEventLoopGroup();
		workerGroup = new NioEventLoopGroup();
		final NettyHttpServer server = this;
		bootstrap.group(bossGroup, workerGroup).channel(NioServerSocketChannel.class)
				.childHandler(new ChannelInitializer<SocketChannel>()
				{
					public void initChannel(SocketChannel ch) throws Exception
					{
						ch.pipeline().addLast("readtimeout", new ReadTimeoutHandler(readTimeout));
						ch.pipeline().addLast("writetimeout",
								new WriteTimeoutHandler(writeTimeout));
						ch.pipeline().addLast("decoder", new HttpRequestDecoder()); // inbound:1
						ch.pipeline().addLast("encoder", new HttpResponseEncoder()); // outbound:2
						ch.pipeline().addLast("aggregator",
								new HttpObjectAggregator(maxContentLength)); // inbound:2
						ch.pipeline().addLast("deflater", new HttpContentCompressor()); // outbound:1
						ch.pipeline().addLast("handler", new HttpServerInboundHandler(server)); // inbound:3
					}
				}).option(ChannelOption.SO_BACKLOG, 128)
				.childOption(ChannelOption.SO_KEEPALIVE, true);

		channel = bootstrap.bind(port).sync();
		// channel.channel().closeFuture().sync();
	}

	@PreDestroy
	public void shutdown()
	{
		log.info("shutdown {} gracefully...", port);
		if (channel != null) channel.channel().close();
		if (workerGroup != null) workerGroup.shutdownGracefully();
		if (bossGroup != null) bossGroup.shutdownGracefully();
	}

	public void setEsbService(ESBService esbService)
	{
		this.esbService = esbService;
	}

	public void setConverter(MessageConverter converter)
	{
		this.converter = converter;
	}

	public void setPort(int port)
	{
		this.port = port;
	}

	public void setReadTimeout(int readTimeout)
	{
		this.readTimeout = readTimeout;
	}

	public void setWriteTimeout(int writeTimeout)
	{
		this.writeTimeout = writeTimeout;
	}

	public void setMaxContentLength(int maxContentLength)
	{
		this.maxContentLength = maxContentLength;
	}
}

class HttpServerInboundHandler extends SimpleChannelInboundHandler<HttpObject>
{
	protected final Logger log = LoggerFactory.getLogger(getClass());
	protected FullHttpRequest fullHttpRequest;
	protected NettyHttpServer server;
	protected String contentType = "text/plain;charset=UTF-8";

	public HttpServerInboundHandler(NettyHttpServer server)
	{
		this.server = server;
	}

	public void messageReceived(ChannelHandlerContext ctx, HttpObject msg) throws Exception
	{
		fullHttpRequest = (FullHttpRequest) msg;
		log.info("{} {}, len:{}", fullHttpRequest.method(), fullHttpRequest.uri(),
				fullHttpRequest.headers().get(HttpHeaderNames.CONTENT_LENGTH));

		// if (HttpDemoServer.isSSL) {
		// System.out.println("Your session is protected by "
		// +
		// ctx.pipeline().get(SslHandler.class).engine().getSession().getCipherSuite()
		// + " cipher suite.\n");
		// }
		if (log.isDebugEnabled()) log.debug(showHeaders());

		if (fullHttpRequest.method().equals(HttpMethod.POST)) doPost(ctx);
		else log.info("Not POST {}", showHeaders());
	}

	protected String showHeaders()
	{
		StringBuilder str = new StringBuilder();
		for (Entry<String, String> entry : fullHttpRequest.headers())
			str.append("header: " + entry.getKey() + '=' + entry.getValue() + "\r\n");
		return str.toString();
	}

	protected void doPost(ChannelHandlerContext ctx) throws Exception
	{
		byte[] request = fullHttpRequest.content().copy().array();
		log.info("request len:{}", request.length);
		IMessage msg = server.converter.deserialize(request);
		msg = server.esbService.sync(msg);
		byte[] buf = server.converter.serialize(msg);
		writeResponse(ctx.channel(), buf);
	}

	protected void writeResponse(Channel channel, byte[] buf)
	{
		// Decide whether to close the connection or not.
		// Decide whether to close the connection or not.
		boolean close = fullHttpRequest.headers().contains(HttpHeaderNames.CONNECTION,
				HttpHeaderValues.CLOSE, true)
				|| (fullHttpRequest.protocolVersion().equals(HttpVersion.HTTP_1_0)
						&& !fullHttpRequest.headers().contains(HttpHeaderNames.CONNECTION,
								HttpHeaderValues.KEEP_ALIVE, true));

		// Build the response object.
		FullHttpResponse response = new DefaultFullHttpResponse(HttpVersion.HTTP_1_1,
				HttpResponseStatus.OK, Unpooled.copiedBuffer(buf));
		response.headers().set(HttpHeaderNames.CONTENT_TYPE, contentType);
		response.headers().set(HttpHeaderNames.CONTENT_LENGTH, buf.length);
		log.info("response close:{}, len:{}", close, buf.length);

		// Write the response.
		ChannelFuture future = channel.writeAndFlush(response);
		// Close the connection after the write operation is done if necessary.
		if (close) future.addListener(ChannelFutureListener.CLOSE);
	}

	@Override
	public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) throws Exception
	{
		log.warn("ex: " + server.port, cause);
		ctx.channel().close();
	}

	@Override
	protected void channelRead0(ChannelHandlerContext ctx, HttpObject msg) throws Exception
	{
		messageReceived(ctx, msg);
	}
}
