package spc.esb.core.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang3.time.FastDateFormat;
import org.springframework.beans.factory.annotation.Autowired;

import spc.esb.common.service.AuthService;
import spc.esb.common.service.ESBInfoService;
import spc.esb.common.service.JournalService;
import spc.esb.common.service.MsgDefService;
import spc.esb.common.service.SignatureService;
import spc.esb.core.service.CoreService;
import spc.esb.core.service.ESBService;
import spc.esb.data.ICompositeNode;
import spc.esb.data.IMessage;
import spc.esb.data.Message;
import spc.esb.data.converter.CoreMessageConverter;
import spc.esb.data.converter.MessageConverter;
import spc.esb.data.converter.NodeConverterFactory;
import spc.esb.data.converter.SOAPConverter;
import spc.esb.endpoint.Endpoint;
import spc.esb.endpoint.EndpointFactory;
import spc.esb.endpoint.Executable;
import spc.esb.model.MessagePO;
import spc.webos.advice.log.LogTrace;
import spc.webos.exception.AppException;
import spc.webos.exception.Status;
import spc.webos.service.BaseService;
import spc.webos.service.seq.UUID;
import spc.webos.util.SpringUtil;
import spc.webos.util.StringX;

public class ESBServiceImpl extends BaseService implements ESBService
{
	@Override
	@LogTrace
	public IMessage sync(IMessage msg)
	{
		log.info("sync sn:{}, msgCd:{}", msg.getMsgSn(), msg.getMsgCd());
		try
		{
			byte[] buf = request(msg);
			call(msg, buf);
			response(msg);
			return msg;
		}
		catch (Exception e)
		{
			log.info("fail to sync:" + msg.getMsgSn(), e);
			msg.setStatus(SpringUtil.ex2status("", e));
			if (req2rep(msg))
			{ // gen snd info
				genSndInf(msg);
				msg.setSndAppCd("ESB");
				msg.setMsgCd("ESB.00000001.01");
			}
			msg.setBody(null); // ���body����
		}
		return msg;
	}

	protected Executable call(IMessage msg, byte[] buf) throws Exception
	{
		String sn = msg.getMsgSn();
		String location = msgDefService.getLocation(msg);
		log.info("call endpoint:{}", location);
		// �п���endpoint�ǳ�����
		Endpoint endpoint = location.indexOf(':') > 0 ? EndpointFactory.getEndpoint(location)
				: esbInfoService.getEndpoint(location);
		Executable exe = new Executable(sn, buf);
		exe.reqmsg = msg;
		endpoint.execute(exe);
		msg.setOriginalBytes(exe.response);
		if (req2rep(msg))
		{ // ��������Ƕ������ģ�������ǰ���Ļ���һ����������Ҫת��ΪӦ����
			String rcvAppCd = msg.getRcvApp();
			if (!StringX.nullity(rcvAppCd)) msg.setSndAppCd(rcvAppCd);
			genSndInf(msg);
		}
		if (StringX.nullity(msg.getSeqNb())) msg.setSeqNb(String.valueOf(uuid.uuid()));
		return exe;
	}

	@Override
	@LogTrace
	public byte[] request(IMessage msg) throws Exception
	{
		log.info("request:{}", msg.getMsgSn());
		log.debug("request start:{}", msg);
		CoreMessageConverter cmc = coreService.getCoreMsgConverter(msg, true, false);
		if (cmc != null) cmc.app2esb(msg, true);

		MessagePO msgPO = msgDefService.getMessage(msg.getMsgCd());
		if (msgPO != null) msg.setRcvAppCd(msgPO.getRcvAppCd());
		authService.isAuth(msg);
		coreService.validateHdr(msg);
		coreService.validateBody(msg);
		coreService.translator(msg);

		log.debug("request end:{}", msg);
		cmc = coreService.getCoreMsgConverter(msg, true, true);
		if (cmc != null) return cmc.esb2app(msg, true);
		return null;
	}

	@Override
	@LogTrace
	public byte[] response(IMessage msg) throws Exception
	{
		log.info("response:{}", msg.getRefMsgSn());
		CoreMessageConverter cmc = coreService.getCoreMsgConverter(msg, false, true);
		if (cmc != null) cmc.app2esb(msg, false);

		log.debug("response start:{}", msg);
		msg.setRcvAppCd(null);
		coreService.validateHdr(msg);
		coreService.validateBody(msg);
		coreService.translator(msg);
		log.debug("response end:{}", msg);

		cmc = coreService.getCoreMsgConverter(msg, false, false);
		if (cmc != null) return cmc.esb2app(msg, false);
		return null;
	}

	@LogTrace
	public <T> T call(String msgCd, Object request, T response)
	{
		log.info("call:{}", msgCd);
		Message msg = new Message();
		genSndInf(msg);
		msg.setSndAppCd("ESB");
		msg.setMsgCd(msgCd);
		msg.setBody((ICompositeNode) NodeConverterFactory.getInstance().unpack(request, null));
		IMessage rep = sync(msg);
		Status s = rep.getStatus();
		if (s.fail()) throw new AppException(s);
		rep.getBody().toObject(response);
		return response;
	}

	protected boolean req2rep(IMessage msg)
	{
		if (!msg.isRequestMsg()) return false;

		if (StringX.nullity(msg.getRefMsgCd())) msg.setRefMsgCd(msg.getMsgCd());
		if (StringX.nullity(msg.getRefSndNode()))
			msg.setRefSndNode(StringX.nullity(msg.getSndNode()) ? null : msg.getSndNode());
		if (StringX.nullity(msg.getRefSndApp())) msg.setRefSndApp(msg.getSndApp());
		if (StringX.nullity(msg.getRefSndDt())) msg.setRefSndDt(msg.getSndDt());
		if (StringX.nullity(msg.getRefSeqNb())) msg.setRefSeqNb(msg.getSeqNb());
		return true;
	}

	protected void genSndInf(IMessage msg)
	{
		String dt = FastDateFormat.getInstance("yyyyMMddHHmmssSSS").format(new Date());
		msg.setSeqNb(String.valueOf(uuid.uuid()));
		msg.setSndDt(dt.substring(0, 8));
		msg.setSndTm(dt.substring(8, 17));
	}

	@Resource
	protected UUID uuid;
	@Resource
	protected CoreService coreService;
	@Resource
	protected AuthService authService;
	@Resource
	protected ESBInfoService esbInfoService;
	@Resource
	protected MsgDefService msgDefService;
	@Autowired(required = false)
	protected SignatureService signatureService;
	@Autowired(required = false)
	protected JournalService journalService;
	protected MessageConverter converter = new SOAPConverter();

	public void setUuid(UUID uuid)
	{
		this.uuid = uuid;
	}

	public void setCoreService(CoreService coreService)
	{
		this.coreService = coreService;
	}

	public void setAuthService(AuthService authService)
	{
		this.authService = authService;
	}

	public void setEsbInfoService(ESBInfoService esbInfoService)
	{
		this.esbInfoService = esbInfoService;
	}

	public void setMsgDefService(MsgDefService msgDefService)
	{
		this.msgDefService = msgDefService;
	}

	public void setJournalService(JournalService journalService)
	{
		this.journalService = journalService;
	}

	public void setConverter(MessageConverter converter)
	{
		this.converter = converter;
	}
}
