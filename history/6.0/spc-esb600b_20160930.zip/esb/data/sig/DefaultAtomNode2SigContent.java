package spc.esb.data.sig;

import spc.esb.data.IAtomNode;
import spc.esb.data.IMessage;
import spc.esb.data.INode;
import spc.esb.model.MsgSchemaPO;
import spc.webos.util.StringX;

public class DefaultAtomNode2SigContent extends AbstractNode2SigContent
{
	public DefaultAtomNode2SigContent()
	{
		name = "Y";
	}

	public String sigCnt(IMessage msg, String nodeCd, INode value, MsgSchemaPO schema)
	{
		return value == null ? StringX.EMPTY_STRING : StringX.trim(((IAtomNode) value)
				.stringValue());
	}
}
