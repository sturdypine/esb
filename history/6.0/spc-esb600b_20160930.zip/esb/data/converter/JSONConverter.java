package spc.esb.data.converter;

import spc.esb.data.AtomNode;
import spc.esb.data.IMessage;
import spc.webos.util.JsonUtil;

public class JSONConverter extends SOAPConverter
{
	public byte[] serialize(IMessage msg) throws Exception
	{
		return JsonUtil.obj2json(msg.getTransaction(), AtomNode.class).getBytes(charset);
	}
}
