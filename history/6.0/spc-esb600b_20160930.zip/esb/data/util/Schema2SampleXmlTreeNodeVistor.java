package spc.esb.data.util;

import spc.esb.data.INode;
import spc.esb.model.MsgSchemaPO;
import spc.webos.util.StringX;
import spc.webos.util.tree.ITreeNodeVistor;
import spc.webos.util.tree.TreeNode;

/**
 * ���ݱ��ĵ�schema�ṹ������������
 * 
 * @author spc
 * 
 */
public class Schema2SampleXmlTreeNodeVistor implements ITreeNodeVistor
{
	protected StringBuffer buf = new StringBuffer();
	protected int level;

	public Schema2SampleXmlTreeNodeVistor()
	{
	}

	public Schema2SampleXmlTreeNodeVistor(int level)
	{
		this.level = level;
	}

	public boolean start(TreeNode treeNode)
	{
		MsgSchemaPO schema = (MsgSchemaPO) treeNode.getTreeNodeValue();
		buf.append(pretty());
		buf.append('<');
		buf.append(schema.getEsbName());
		buf.append('>');
		if (schema.getFtyp().charAt(0) == INode.TYPE_MAP
				|| schema.getFtyp().charAt(0) == INode.TYPE_ARRAY) level++;
		else
		{
			buf.append(getAtomValue(schema));
			buf.append('<');
			buf.append('/');
			buf.append(schema.getEsbName());
			buf.append('>');
		}
		return true;
	}

	protected String getAtomValue(MsgSchemaPO schema)
	{
		return StringX.null2emptystr(schema.getDefValue());
	}

	public boolean end(TreeNode treeNode)
	{
		MsgSchemaPO schema = (MsgSchemaPO) treeNode.getTreeNodeValue();
		if (schema.getFtyp().charAt(0) == INode.TYPE_MAP
				|| schema.getFtyp().charAt(0) == INode.TYPE_ARRAY)
		{
			level--;
			buf.append(pretty());
			buf.append('<');
			buf.append('/');
			buf.append(schema.getEsbName());
			buf.append('>');
		}
		return true;
	}

	protected String pretty()
	{
		StringBuffer buf = new StringBuffer();
		buf.append('\n');
		for (int i = 0; i < level; i++)
			buf.append('\t');
		return buf.toString();
	}

	public void clear()
	{
		buf.setLength(0);
	}

	public void setLevel(int level)
	{
		this.level = level;
	}

	public String toXml()
	{
		return buf.toString();
	}

	public String toString()
	{
		return buf.toString();
	}
}
